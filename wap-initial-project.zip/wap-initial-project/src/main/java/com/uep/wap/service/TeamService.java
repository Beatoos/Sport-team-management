package com.uep.wap.service;

import com.uep.wap.model.Team;
import com.uep.wap.repository.TeamRepository;
import com.uep.wap.dto.TeamDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TeamService {

    @Autowired
    private TeamRepository teamRepository;

    public void addTeam(TeamDTO teamDTO) {

        Team team = new Team();

        team.setName(teamDTO.getName());
        team.setCity(teamDTO.getCity());
        team.setOffenseRating(teamDTO.getOffenseRating());
        team.setDefenseRating(teamDTO.getDefenseRating());

        teamRepository.save(team);

        System.out.println("Team added!");
    }

    public Iterable<Team> getAllTeams() {
        return teamRepository.findAll();
    }

}