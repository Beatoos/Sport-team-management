package com.uep.wap.service;

import com.uep.wap.model.Role;
import com.uep.wap.repository.RoleRepository;
import com.uep.wap.dto.RoleDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleService {

    @Autowired
    private RoleRepository roleRepository;

    public void addRole(RoleDTO roleDTO) {

        Role role = new Role();

        role.setRoleName(roleDTO.getRoleName());

        roleRepository.save(role);

        System.out.println("Role added!");
    }

    public Iterable<Role> getAllRoles() {
        return roleRepository.findAll();
    }

}