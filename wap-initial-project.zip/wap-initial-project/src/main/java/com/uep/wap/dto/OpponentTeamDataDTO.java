package com.uep.wap.dto;

import java.util.List;

public class OpponentTeamDataDTO {

    private List<OpponentTeamDTO> opponentTeams;

    public List<OpponentTeamDTO> getOpponentTeams() {
        return opponentTeams;
    }

    public void setOpponentTeams(List<OpponentTeamDTO> opponentTeams) {
        this.opponentTeams = opponentTeams;
    }
}