package com.uep.wap.dto;

import java.util.List;

public class PlayerDataDTO {

    private List<PlayerDTO> players;

    public List<PlayerDTO> getPlayers() {
        return players;
    }

    public void setPlayers(List<PlayerDTO> players) {
        this.players = players;
    }
}