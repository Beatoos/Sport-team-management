package com.uep.wap.dto;

import java.util.List;

public class MatchupAnalysisDataDTO {

    private List<MatchupAnalysisDTO> matchupAnalysis;

    public List<MatchupAnalysisDTO> getMatchupAnalysis() {
        return matchupAnalysis;
    }

    public void setMatchupAnalysis(List<MatchupAnalysisDTO> matchupAnalysis) {
        this.matchupAnalysis = matchupAnalysis;
    }
}