package com.uep.wap.controller;

import com.uep.wap.dto.LineupDTO;
import com.uep.wap.model.Lineup;
import com.uep.wap.service.LineupService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api")
public class LineupController {

    private final LineupService lineupService;

    public LineupController(LineupService lineupService) {
        this.lineupService = lineupService;
    }

    @GetMapping(path = "/lineups")
    public Iterable<Lineup> getAllLineups() {
        return lineupService.getAllLineups();
    }

    @PostMapping(path = "/lineups")
    public String addLineup(@RequestBody LineupDTO lineupDTO) {
        lineupService.addLineup(lineupDTO);
        return "Lineup added!";
    }

}