package com.uep.wap.dto;

import java.util.List;

public class PlayerStatsDataDTO {

    private List<PlayerStatsDTO> playerStats;

    public List<PlayerStatsDTO> getPlayerStats() {
        return playerStats;
    }

    public void setPlayerStats(List<PlayerStatsDTO> playerStats) {
        this.playerStats = playerStats;
    }
}