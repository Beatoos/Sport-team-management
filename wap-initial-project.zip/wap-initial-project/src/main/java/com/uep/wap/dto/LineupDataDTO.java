package com.uep.wap.dto;

import java.util.List;

public class LineupDataDTO {

    private List<LineupDTO> lineups;

    public List<LineupDTO> getLineups() {
        return lineups;
    }

    public void setLineups(List<LineupDTO> lineups) {
        this.lineups = lineups;
    }
}