package com.uep.wap.dto;

public class TeamDTO {

    private String name;
    private String city;
    private double offenseRating;
    private double defenseRating;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public double getOffenseRating() {
        return offenseRating;
    }

    public void setOffenseRating(double offenseRating) {
        this.offenseRating = offenseRating;
    }

    public double getDefenseRating() {
        return defenseRating;
    }

    public void setDefenseRating(double defenseRating) {
        this.defenseRating = defenseRating;
    }
}