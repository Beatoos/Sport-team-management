package com.uep.wap.controller;

import com.uep.wap.dto.OpponentTeamDTO;
import com.uep.wap.model.OpponentTeam;
import com.uep.wap.service.OpponentTeamService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api")
public class OpponentTeamController {

    private final OpponentTeamService opponentTeamService;

    public OpponentTeamController(OpponentTeamService opponentTeamService) {
        this.opponentTeamService = opponentTeamService;
    }

    @GetMapping(path = "/opponent-teams")
    public Iterable<OpponentTeam> getAllOpponentTeams() {
        return opponentTeamService.getAllOpponentTeams();
    }

    @PostMapping(path = "/opponent-teams")
    public String addOpponentTeam(@RequestBody OpponentTeamDTO opponentTeamDTO) {
        opponentTeamService.addOpponentTeam(opponentTeamDTO);
        return "Opponent team added!";
    }

}