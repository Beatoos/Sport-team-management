package com.uep.wap.service;

import com.uep.wap.model.Player;
import com.uep.wap.model.Team;
import com.uep.wap.repository.PlayerRepository;
import com.uep.wap.repository.TeamRepository;
import com.uep.wap.dto.PlayerDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PlayerService {

    @Autowired
    private PlayerRepository playerRepository;

    @Autowired
    private TeamRepository teamRepository;

    public void addPlayer(PlayerDTO playerDTO) {

        Player player = new Player();
        player.setName(playerDTO.getName());
        player.setSurname(playerDTO.getSurname());
        player.setPosition(playerDTO.getPosition());
        player.setHeigth(playerDTO.getHeigth());
        player.setWeigth(playerDTO.getWeigth());

        // 🔥 ważne: przypisanie teamu
        if(playerDTO.getTeamId() != null) {
            Team team = teamRepository.findById(playerDTO.getTeamId()).orElse(null);
            player.setTeam(team);
        }

        playerRepository.save(player);

        System.out.println("Player added!");
    }

    public Iterable<Player> getAllPlayers() {
        return playerRepository.findAll();
    }

}