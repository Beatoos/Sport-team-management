package com.uep.wap.controller;

import com.uep.wap.dto.MatchupAnalysisDTO;
import com.uep.wap.model.MatchupAnalysis;
import com.uep.wap.service.MatchupAnalysisService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api")
public class MatchupAnalysisController {

    private final MatchupAnalysisService matchupAnalysisService;

    public MatchupAnalysisController(MatchupAnalysisService matchupAnalysisService) {
        this.matchupAnalysisService = matchupAnalysisService;
    }

    @GetMapping(path = "/matchup-analysis")
    public Iterable<MatchupAnalysis> getAllMatchupAnalysis() {
        return matchupAnalysisService.getAllMatchupAnalysis();
    }

    @PostMapping(path = "/matchup-analysis")
    public String addMatchupAnalysis(@RequestBody MatchupAnalysisDTO matchupAnalysisDTO) {
        matchupAnalysisService.addMatchupAnalysis(matchupAnalysisDTO);
        return "Matchup analysis added!";
    }

}