package com.uep.wap.model;

import javax.persistence.*;

@Entity
@Table(name="opponent_teams")
public class OpponentTeam {

    @Id
    @Column(name ="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name ="name")
    private String name;

    @Column(name ="offenseRating")
    private double offenseRating;

    @Column(name ="defenseRating")
    private double defenseRating;

    @Column(name ="threePointDefense")
    private double threePointDefense;

    @Column(name ="reboundRate")
    private double reboundRate;


    public void setId(long id){
        this.id = id;
    }

    public long getId(){
        return id;
    }

    public OpponentTeam(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getOffenseRating() {
        return offenseRating;
    }

    public void setOffenseRating(double offenseRating) {
        this.offenseRating = offenseRating;
    }

    public double getDefenseRating() {
        return defenseRating;
    }

    public void setDefenseRating(double defenseRating) {
        this.defenseRating = defenseRating;
    }

    public double getThreePointDefense() {
        return threePointDefense;
    }

    public void setThreePointDefense(double threePointDefense) {
        this.threePointDefense = threePointDefense;
    }

    public double getReboundRate() {
        return reboundRate;
    }

    public void setReboundRate(double reboundRate) {
        this.reboundRate = reboundRate;
    }

    public OpponentTeam(String name, double offenseRating, double defenseRating, double threePointDefense, double reboundRate){

    }
}
