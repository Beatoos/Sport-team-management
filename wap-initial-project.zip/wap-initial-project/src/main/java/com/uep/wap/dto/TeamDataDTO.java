package com.uep.wap.dto;

import java.util.List;

public class TeamDataDTO {

    private List<TeamDTO> teams;

    public List<TeamDTO> getTeams() {

        return teams;

    }

    public void setTeams(List<TeamDTO> teams) {

        this.teams = teams;

    }

}