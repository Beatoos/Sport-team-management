package com.uep.wap.repository;

import com.uep.wap.model.OpponentTeam;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OpponentTeamRepository extends CrudRepository<OpponentTeam, Long> {

}