package com.uep.wap.dto;

public class PlayerStatsDTO {

    private int closeShot;
    private int drivingLayup;
    private int drivingDunk;
    private int standingDunk;
    private int postHook;

    private int midRangeShot;
    private int threePointShot;
    private int freeThrow;
    private int postFade;

    private int passAccuracy;
    private int ballHandle;
    private int postMoves;

    private int interiorDefense;
    private int perimeterDefense;
    private int lateralQuickness;
    private int steal;
    private int block;
    private int offensiveRebound;
    private int defensiveRebound;

    private Long playerId;

    public int getCloseShot() {
        return closeShot;
    }

    public void setCloseShot(int closeShot) {
        this.closeShot = closeShot;
    }

    public int getDrivingLayup() {
        return drivingLayup;
    }

    public void setDrivingLayup(int drivingLayup) {
        this.drivingLayup = drivingLayup;
    }

    public int getDrivingDunk() {
        return drivingDunk;
    }

    public void setDrivingDunk(int drivingDunk) {
        this.drivingDunk = drivingDunk;
    }

    public int getStandingDunk() {
        return standingDunk;
    }

    public void setStandingDunk(int standingDunk) {
        this.standingDunk = standingDunk;
    }

    public int getPostHook() {
        return postHook;
    }

    public void setPostHook(int postHook) {
        this.postHook = postHook;
    }

    public int getMidRangeShot() {
        return midRangeShot;
    }

    public void setMidRangeShot(int midRangeShot) {
        this.midRangeShot = midRangeShot;
    }

    public int getThreePointShot() {
        return threePointShot;
    }

    public void setThreePointShot(int threePointShot) {
        this.threePointShot = threePointShot;
    }

    public int getFreeThrow() {
        return freeThrow;
    }

    public void setFreeThrow(int freeThrow) {
        this.freeThrow = freeThrow;
    }

    public int getPostFade() {
        return postFade;
    }

    public void setPostFade(int postFade) {
        this.postFade = postFade;
    }

    public int getPassAccuracy() {
        return passAccuracy;
    }

    public void setPassAccuracy(int passAccuracy) {
        this.passAccuracy = passAccuracy;
    }

    public int getBallHandle() {
        return ballHandle;
    }

    public void setBallHandle(int ballHandle) {
        this.ballHandle = ballHandle;
    }

    public int getPostMoves() {
        return postMoves;
    }

    public void setPostMoves(int postMoves) {
        this.postMoves = postMoves;
    }

    public int getInteriorDefense() {
        return interiorDefense;
    }

    public void setInteriorDefense(int interiorDefense) {
        this.interiorDefense = interiorDefense;
    }

    public int getPerimeterDefense() {
        return perimeterDefense;
    }

    public void setPerimeterDefense(int perimeterDefense) {
        this.perimeterDefense = perimeterDefense;
    }

    public int getLateralQuickness() {
        return lateralQuickness;
    }

    public void setLateralQuickness(int lateralQuickness) {
        this.lateralQuickness = lateralQuickness;
    }

    public int getSteal() {
        return steal;
    }

    public void setSteal(int steal) {
        this.steal = steal;
    }

    public int getBlock() {
        return block;
    }

    public void setBlock(int block) {
        this.block = block;
    }

    public int getOffensiveRebound() {
        return offensiveRebound;
    }

    public void setOffensiveRebound(int offensiveRebound) {
        this.offensiveRebound = offensiveRebound;
    }

    public int getDefensiveRebound() {
        return defensiveRebound;
    }

    public void setDefensiveRebound(int defensiveRebound) {
        this.defensiveRebound = defensiveRebound;
    }

    public Long getPlayerId() {
        return playerId;
    }

    public void setPlayerId(Long playerId) {
        this.playerId = playerId;
    }
}