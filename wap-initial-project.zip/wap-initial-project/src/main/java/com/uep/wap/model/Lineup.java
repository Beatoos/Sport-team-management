package com.uep.wap.model;

import javax.persistence.*;

@Entity
@Table(name="lineups")
public class Lineup {

    @Id
    @Column(name ="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne
    @JoinColumn(name="pg_id")
    private Player pg;

    @ManyToOne
    @JoinColumn(name="sg_id")
    private Player sg;

    @ManyToOne
    @JoinColumn(name="sf_id")
    private Player sf;

    @ManyToOne
    @JoinColumn(name="pf_id")
    private Player pf;

    @ManyToOne
    @JoinColumn(name="c_id")
    private Player c;

    @ManyToOne
    @JoinColumn(name="user_id")
    private User createdBy;


    public void setId(long id){
        this.id = id;
    }

    public long getId(){
        return id;
    }

    public Lineup(){

    }

    public Player getPg() {
        return pg;
    }

    public void setPg(Player pg) {
        this.pg = pg;
    }

    public Player getSg() {
        return sg;
    }

    public void setSg(Player sg) {
        this.sg = sg;
    }

    public Player getSf() {
        return sf;
    }

    public void setSf(Player sf) {
        this.sf = sf;
    }

    public Player getPf() {
        return pf;
    }

    public void setPf(Player pf) {
        this.pf = pf;
    }

    public Player getC() {
        return c;
    }

    public void setC(Player c) {
        this.c = c;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public Lineup(Player pg, Player sg, Player sf, Player pf, Player c, User createdBy){

    }
}
