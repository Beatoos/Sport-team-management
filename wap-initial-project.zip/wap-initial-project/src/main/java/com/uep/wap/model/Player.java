package com.uep.wap.model;


import javax.persistence.*;

@Entity
@Table(name="players")
public class Player {
    @Id
    @Column(name ="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name ="name")
    private String name;
    @Column(name ="surname")
    private String surname;
    @Column(name ="position")
    private Integer position;
    @Column(name ="heigth")
    private Integer heigth;
    @Column(name = "weigth")
    private Integer weigth;
    @ManyToOne
    @JoinColumn(name="team_id")
    private Team team;

    public void setId(long id){
        this.id = id;
    }

    public long getId(){
        return id;
    }

    public Player(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public Integer getHeigth() {
        return heigth;
    }

    public void setHeigth(Integer heigth) {
        this.heigth = heigth;
    }

    public Integer getWeigth() {
        return weigth;
    }

    public void setWeigth(Integer weigth) {
        this.weigth = weigth;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public Player(String name, String surname, Integer position, Integer heigth, Integer weigth, Team team){

    }
}
    



