package com.uep.wap.dto;

public class LineupDTO {

    private Long pgId;
    private Long sgId;
    private Long sfId;
    private Long pfId;
    private Long cId;
    private Long createdById;

    public Long getPgId() {
        return pgId;
    }

    public void setPgId(Long pgId) {
        this.pgId = pgId;
    }

    public Long getSgId() {
        return sgId;
    }

    public void setSgId(Long sgId) {
        this.sgId = sgId;
    }

    public Long getSfId() {
        return sfId;
    }

    public void setSfId(Long sfId) {
        this.sfId = sfId;
    }

    public Long getPfId() {
        return pfId;
    }

    public void setPfId(Long pfId) {
        this.pfId = pfId;
    }

    public Long getCId() {
        return cId;
    }

    public void setCId(Long cId) {
        this.cId = cId;
    }

    public Long getCreatedById() {
        return createdById;
    }

    public void setCreatedById(Long createdById) {
        this.createdById = createdById;
    }
}