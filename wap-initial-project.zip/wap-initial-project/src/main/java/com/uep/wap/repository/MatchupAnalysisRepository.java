package com.uep.wap.repository;

import com.uep.wap.model.MatchupAnalysis;
import com.uep.wap.model.Lineup;
import com.uep.wap.model.OpponentTeam;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MatchupAnalysisRepository extends CrudRepository<MatchupAnalysis, Long> {

    List<MatchupAnalysis> findByLineup(Lineup lineup);

    List<MatchupAnalysis> findByOpponent(OpponentTeam opponent);

}