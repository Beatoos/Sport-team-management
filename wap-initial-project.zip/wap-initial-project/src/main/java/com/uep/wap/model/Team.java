package com.uep.wap.model;

import javax.persistence.*;

@Entity
@Table(name="teams")
public class Team {

    @Id
    @Column(name ="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name ="name")
    private String name;

    @Column(name ="city")
    private String city;

    @Column(name ="offenseRating")
    private double offenseRating;

    @Column(name ="defenseRating")
    private double defenseRating;


    public void setId(long id){
        this.id = id;
    }

    public long getId(){
        return id;
    }

    public Team(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public double getOffenseRating() {
        return offenseRating;
    }

    public void setOffenseRating(double offenseRating) {
        this.offenseRating = offenseRating;
    }

    public double getDefenseRating() {
        return defenseRating;
    }

    public void setDefenseRating(double defenseRating) {
        this.defenseRating = defenseRating;
    }

    public Team(String name, String city, double offenseRating, double defenseRating){

    }
}