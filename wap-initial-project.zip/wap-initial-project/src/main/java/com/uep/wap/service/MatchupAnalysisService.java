package com.uep.wap.service;

import com.uep.wap.model.Lineup;
import com.uep.wap.model.MatchupAnalysis;
import com.uep.wap.model.OpponentTeam;
import com.uep.wap.repository.LineupRepository;
import com.uep.wap.repository.MatchupAnalysisRepository;
import com.uep.wap.repository.OpponentTeamRepository;
import com.uep.wap.dto.MatchupAnalysisDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MatchupAnalysisService {

    @Autowired
    private MatchupAnalysisRepository matchupAnalysisRepository;

    @Autowired
    private LineupRepository lineupRepository;

    @Autowired
    private OpponentTeamRepository opponentTeamRepository;

    public void addMatchupAnalysis(MatchupAnalysisDTO matchupAnalysisDTO) {

        MatchupAnalysis matchupAnalysis = new MatchupAnalysis();

        matchupAnalysis.setScore(matchupAnalysisDTO.getScore());
        matchupAnalysis.setStrengths(matchupAnalysisDTO.getStrengths());
        matchupAnalysis.setWeaknesses(matchupAnalysisDTO.getWeaknesses());

        if(matchupAnalysisDTO.getLineupId() != null) {
            Lineup lineup = lineupRepository.findById(matchupAnalysisDTO.getLineupId()).orElse(null);
            matchupAnalysis.setLineup(lineup);
        }

        if(matchupAnalysisDTO.getOpponentId() != null) {
            OpponentTeam opponent = opponentTeamRepository.findById(matchupAnalysisDTO.getOpponentId()).orElse(null);
            matchupAnalysis.setOpponent(opponent);
        }

        matchupAnalysisRepository.save(matchupAnalysis);

        System.out.println("Matchup analysis added!");
    }

    public Iterable<MatchupAnalysis> getAllMatchupAnalysis() {
        return matchupAnalysisRepository.findAll();
    }

}