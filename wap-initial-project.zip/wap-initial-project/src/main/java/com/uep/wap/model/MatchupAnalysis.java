package com.uep.wap.model;

import javax.persistence.*;

@Entity
@Table(name="matchup_analysis")
public class MatchupAnalysis {

    @Id
    @Column(name ="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name ="score")
    private int score;

    @Column(name ="strengths")
    private String strengths;

    @Column(name ="weaknesses")
    private String weaknesses;

    @ManyToOne
    @JoinColumn(name="lineup_id")
    private Lineup lineup;

    @ManyToOne
    @JoinColumn(name="opponent_id")
    private OpponentTeam opponent;


    public void setId(long id){
        this.id = id;
    }

    public long getId(){
        return id;
    }

    public MatchupAnalysis(){

    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getStrengths() {
        return strengths;
    }

    public void setStrengths(String strengths) {
        this.strengths = strengths;
    }

    public String getWeaknesses() {
        return weaknesses;
    }

    public void setWeaknesses(String weaknesses) {
        this.weaknesses = weaknesses;
    }

    public Lineup getLineup() {
        return lineup;
    }

    public void setLineup(Lineup lineup) {
        this.lineup = lineup;
    }

    public OpponentTeam getOpponent() {
        return opponent;
    }

    public void setOpponent(OpponentTeam opponent) {
        this.opponent = opponent;
    }

    public MatchupAnalysis(int score, String strengths, String weaknesses, Lineup lineup, OpponentTeam opponent){

    }
}