package com.uep.wap.controller;

import com.uep.wap.dto.PlayerStatsDTO;
import com.uep.wap.model.PlayerStats;
import com.uep.wap.service.PlayerStatsService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api")
public class PlayerStatsController {

    private final PlayerStatsService playerStatsService;

    public PlayerStatsController(PlayerStatsService playerStatsService) {
        this.playerStatsService = playerStatsService;
    }

    @GetMapping(path = "/player-stats")
    public Iterable<PlayerStats> getAllPlayerStats() {
        return playerStatsService.getAllPlayerStats();
    }

    @PostMapping(path = "/player-stats")
    public String addPlayerStats(@RequestBody PlayerStatsDTO playerStatsDTO) {
        playerStatsService.addPlayerStats(playerStatsDTO);
        return "Player stats added!";
    }

}