package com.uep.wap.dto;

public class OpponentTeamDTO {

    private String name;
    private double offenseRating;
    private double defenseRating;
    private double threePointDefense;
    private double reboundRate;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getOffenseRating() {
        return offenseRating;
    }

    public void setOffenseRating(double offenseRating) {
        this.offenseRating = offenseRating;
    }

    public double getDefenseRating() {
        return defenseRating;
    }

    public void setDefenseRating(double defenseRating) {
        this.defenseRating = defenseRating;
    }

    public double getThreePointDefense() {
        return threePointDefense;
    }

    public void setThreePointDefense(double threePointDefense) {
        this.threePointDefense = threePointDefense;
    }

    public double getReboundRate() {
        return reboundRate;
    }

    public void setReboundRate(double reboundRate) {
        this.reboundRate = reboundRate;
    }
}