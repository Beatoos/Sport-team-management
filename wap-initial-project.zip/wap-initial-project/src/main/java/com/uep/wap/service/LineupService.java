package com.uep.wap.service;

import com.uep.wap.model.Lineup;
import com.uep.wap.model.Player;
import com.uep.wap.model.User;
import com.uep.wap.repository.LineupRepository;
import com.uep.wap.repository.PlayerRepository;
import com.uep.wap.repository.UserRepository;
import com.uep.wap.dto.LineupDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LineupService {

    @Autowired
    private LineupRepository lineupRepository;

    @Autowired
    private PlayerRepository playerRepository;

    @Autowired
    private UserRepository userRepository;

    public void addLineup(LineupDTO lineupDTO) {

        Lineup lineup = new Lineup();

        if(lineupDTO.getPgId() != null) {
            Player pg = playerRepository.findById(lineupDTO.getPgId()).orElse(null);
            lineup.setPg(pg);
        }

        if(lineupDTO.getSgId() != null) {
            Player sg = playerRepository.findById(lineupDTO.getSgId()).orElse(null);
            lineup.setSg(sg);
        }

        if(lineupDTO.getSfId() != null) {
            Player sf = playerRepository.findById(lineupDTO.getSfId()).orElse(null);
            lineup.setSf(sf);
        }

        if(lineupDTO.getPfId() != null) {
            Player pf = playerRepository.findById(lineupDTO.getPfId()).orElse(null);
            lineup.setPf(pf);
        }

        if(lineupDTO.getCId() != null) {
            Player c = playerRepository.findById(lineupDTO.getCId()).orElse(null);
            lineup.setC(c);
        }

        if(lineupDTO.getCreatedById() != null) {
            User user = userRepository.findById(lineupDTO.getCreatedById()).orElse(null);
            lineup.setCreatedBy(user);
        }

        lineupRepository.save(lineup);

        System.out.println("Lineup added!");
    }

    public Iterable<Lineup> getAllLineups() {
        return lineupRepository.findAll();
    }

}