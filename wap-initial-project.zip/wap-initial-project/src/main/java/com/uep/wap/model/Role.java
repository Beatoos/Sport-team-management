package com.uep.wap.model;

import javax.persistence.*;

@Entity
@Table(name="roles")
public class Role {

    @Id
    @Column(name ="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name ="roleName")
    private String roleName;


    public void setId(long id){
        this.id = id;
    }

    public long getId(){
        return id;
    }

    public Role(){

    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Role(String roleName){

    }
}