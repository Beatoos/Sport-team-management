package com.uep.wap.service;

import com.uep.wap.model.OpponentTeam;
import com.uep.wap.repository.OpponentTeamRepository;
import com.uep.wap.dto.OpponentTeamDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OpponentTeamService {

    @Autowired
    private OpponentTeamRepository opponentTeamRepository;

    public void addOpponentTeam(OpponentTeamDTO opponentTeamDTO) {

        OpponentTeam opponentTeam = new OpponentTeam();

        opponentTeam.setName(opponentTeamDTO.getName());
        opponentTeam.setOffenseRating(opponentTeamDTO.getOffenseRating());
        opponentTeam.setDefenseRating(opponentTeamDTO.getDefenseRating());
        opponentTeam.setThreePointDefense(opponentTeamDTO.getThreePointDefense());
        opponentTeam.setReboundRate(opponentTeamDTO.getReboundRate());

        opponentTeamRepository.save(opponentTeam);

        System.out.println("Opponent team added!");
    }

    public Iterable<OpponentTeam> getAllOpponentTeams() {
        return opponentTeamRepository.findAll();
    }

}