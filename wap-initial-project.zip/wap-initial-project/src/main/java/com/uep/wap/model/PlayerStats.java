package com.uep.wap.model;

import javax.persistence.*;

@Entity
@Table(name="player_stats")
public class PlayerStats {

    @Id
    @Column(name ="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name ="closeShot")
    private int closeShot;

    @Column(name ="drivingLayup")
    private int drivingLayup;

    @Column(name ="drivingDunk")
    private int drivingDunk;

    @Column(name ="standingDunk")
    private int standingDunk;

    @Column(name ="postHook")
    private int postHook;

    @Column(name ="midRangeShot")
    private int midRangeShot;

    @Column(name ="threePointShot")
    private int threePointShot;

    @Column(name ="freeThrow")
    private int freeThrow;

    @Column(name ="postFade")
    private int postFade;

    @Column(name ="passAccuracy")
    private int passAccuracy;

    @Column(name ="ballHandle")
    private int ballHandle;

    @Column(name ="postMoves")
    private int postMoves;

    @Column(name ="interiorDefense")
    private int interiorDefense;

    @Column(name ="perimeterDefense")
    private int perimeterDefense;

    @Column(name ="lateralQuickness")
    private int lateralQuickness;

    @Column(name ="steal")
    private int steal;

    @Column(name ="block")
    private int block;

    @Column(name ="offensiveRebound")
    private int offensiveRebound;

    @Column(name ="defensiveRebound")
    private int defensiveRebound;

    @OneToOne
    @JoinColumn(name="player_id")
    private Player player;


    public void setId(long id){
        this.id = id;
    }

    public long getId(){
        return id;
    }

    public PlayerStats(){

    }

    public int getCloseShot() {
        return closeShot;
    }

    public void setCloseShot(int closeShot) {
        this.closeShot = closeShot;
    }

    public int getDrivingLayup() {
        return drivingLayup;
    }

    public void setDrivingLayup(int drivingLayup) {
        this.drivingLayup = drivingLayup;
    }

    public int getDrivingDunk() {
        return drivingDunk;
    }

    public void setDrivingDunk(int drivingDunk) {
        this.drivingDunk = drivingDunk;
    }

    public int getStandingDunk() {
        return standingDunk;
    }

    public void setStandingDunk(int standingDunk) {
        this.standingDunk = standingDunk;
    }

    public int getPostHook() {
        return postHook;
    }

    public void setPostHook(int postHook) {
        this.postHook = postHook;
    }

    public int getMidRangeShot() {
        return midRangeShot;
    }

    public void setMidRangeShot(int midRangeShot) {
        this.midRangeShot = midRangeShot;
    }

    public int getThreePointShot() {
        return threePointShot;
    }

    public void setThreePointShot(int threePointShot) {
        this.threePointShot = threePointShot;
    }

    public int getFreeThrow() {
        return freeThrow;
    }

    public void setFreeThrow(int freeThrow) {
        this.freeThrow = freeThrow;
    }

    public int getPostFade() {
        return postFade;
    }

    public void setPostFade(int postFade) {
        this.postFade = postFade;
    }

    public int getPassAccuracy() {
        return passAccuracy;
    }

    public void setPassAccuracy(int passAccuracy) {
        this.passAccuracy = passAccuracy;
    }

    public int getBallHandle() {
        return ballHandle;
    }

    public void setBallHandle(int ballHandle) {
        this.ballHandle = ballHandle;
    }

    public int getPostMoves() {
        return postMoves;
    }

    public void setPostMoves(int postMoves) {
        this.postMoves = postMoves;
    }

    public int getInteriorDefense() {
        return interiorDefense;
    }

    public void setInteriorDefense(int interiorDefense) {
        this.interiorDefense = interiorDefense;
    }

    public int getPerimeterDefense() {
        return perimeterDefense;
    }

    public void setPerimeterDefense(int perimeterDefense) {
        this.perimeterDefense = perimeterDefense;
    }

    public int getLateralQuickness() {
        return lateralQuickness;
    }

    public void setLateralQuickness(int lateralQuickness) {
        this.lateralQuickness = lateralQuickness;
    }

    public int getSteal() {
        return steal;
    }

    public void setSteal(int steal) {
        this.steal = steal;
    }

    public int getBlock() {
        return block;
    }

    public void setBlock(int block) {
        this.block = block;
    }

    public int getOffensiveRebound() {
        return offensiveRebound;
    }

    public void setOffensiveRebound(int offensiveRebound) {
        this.offensiveRebound = offensiveRebound;
    }

    public int getDefensiveRebound() {
        return defensiveRebound;
    }

    public void setDefensiveRebound(int defensiveRebound) {
        this.defensiveRebound = defensiveRebound;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public PlayerStats(int closeShot, int drivingLayup, int drivingDunk, int standingDunk, int postHook,
                       int midRangeShot, int threePointShot, int freeThrow, int postFade,
                       int passAccuracy, int ballHandle, int postMoves,
                       int interiorDefense, int perimeterDefense, int lateralQuickness,
                       int steal, int block, int offensiveRebound, int defensiveRebound,
                       Player player){

    }
}