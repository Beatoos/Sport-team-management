package com.uep.wap.service;

import com.uep.wap.model.Player;
import com.uep.wap.model.PlayerStats;
import com.uep.wap.repository.PlayerRepository;
import com.uep.wap.repository.PlayerStatsRepository;
import com.uep.wap.dto.PlayerStatsDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PlayerStatsService {

    @Autowired
    private PlayerStatsRepository playerStatsRepository;

    @Autowired
    private PlayerRepository playerRepository;

    public void addPlayerStats(PlayerStatsDTO playerStatsDTO) {

        PlayerStats playerStats = new PlayerStats();

        playerStats.setCloseShot(playerStatsDTO.getCloseShot());
        playerStats.setDrivingLayup(playerStatsDTO.getDrivingLayup());
        playerStats.setDrivingDunk(playerStatsDTO.getDrivingDunk());
        playerStats.setStandingDunk(playerStatsDTO.getStandingDunk());
        playerStats.setPostHook(playerStatsDTO.getPostHook());

        playerStats.setMidRangeShot(playerStatsDTO.getMidRangeShot());
        playerStats.setThreePointShot(playerStatsDTO.getThreePointShot());
        playerStats.setFreeThrow(playerStatsDTO.getFreeThrow());
        playerStats.setPostFade(playerStatsDTO.getPostFade());

        playerStats.setPassAccuracy(playerStatsDTO.getPassAccuracy());
        playerStats.setBallHandle(playerStatsDTO.getBallHandle());
        playerStats.setPostMoves(playerStatsDTO.getPostMoves());

        playerStats.setInteriorDefense(playerStatsDTO.getInteriorDefense());
        playerStats.setPerimeterDefense(playerStatsDTO.getPerimeterDefense());
        playerStats.setLateralQuickness(playerStatsDTO.getLateralQuickness());
        playerStats.setSteal(playerStatsDTO.getSteal());
        playerStats.setBlock(playerStatsDTO.getBlock());
        playerStats.setOffensiveRebound(playerStatsDTO.getOffensiveRebound());
        playerStats.setDefensiveRebound(playerStatsDTO.getDefensiveRebound());

        if(playerStatsDTO.getPlayerId() != null) {
            Player player = playerRepository.findById(playerStatsDTO.getPlayerId()).orElse(null);
            playerStats.setPlayer(player);
        }

        playerStatsRepository.save(playerStats);

        System.out.println("Player stats added!");
    }

    public Iterable<PlayerStats> getAllPlayerStats() {
        return playerStatsRepository.findAll();
    }

}