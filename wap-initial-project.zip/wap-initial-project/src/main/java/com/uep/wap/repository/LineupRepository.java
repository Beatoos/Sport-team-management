package com.uep.wap.repository;

import com.uep.wap.model.Lineup;
import com.uep.wap.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LineupRepository extends CrudRepository<Lineup, Long> {

    List<Lineup> findByCreatedBy(User user);

}