package com.uep.wap.controller;

import com.uep.wap.dto.RoleDTO;
import com.uep.wap.model.Role;
import com.uep.wap.service.RoleService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api")
public class RoleController {

    private final RoleService roleService;

    public RoleController(RoleService roleService) {
        this.roleService = roleService;
    }

    @GetMapping(path = "/roles")
    public Iterable<Role> getAllRoles() {
        return roleService.getAllRoles();
    }

    @PostMapping(path = "/roles")
    public String addRole(@RequestBody RoleDTO roleDTO) {
        roleService.addRole(roleDTO);
        return "Role added!";
    }

}